Lista_resultados = ""

def agregar_caracter(label, caracter):

    global Lista_resultados
    Lista_resultados += str(caracter)
    label.configure(text=Lista_resultados)

def limpiar_pantalla(label):

    global Lista_resultados
    Lista_resultados = ""
    label.configure(text=Lista_resultados)

def calcular_resultado(label):
 
    global Lista_resultados
    try:
        
        resultado = str(eval(Lista_resultados))
        label.configure(text=resultado)
        Lista_resultados = resultado
    except ZeroDivisionError:
        label.configure(text="Error: Div/0")
        Lista_resultados = "" 
    except Exception:
        label.configure(text="Error")
        Lista_resultados = "" 


def boton1(label):
    agregar_caracter(label, "7")
def boton2(label):
    agregar_caracter(label, "8")
def boton3(label):
    agregar_caracter(label, "9")
def boton4(label):
    agregar_caracter(label, "/")
def boton5(label):
    agregar_caracter(label, "4")
def boton6(label):
    agregar_caracter(label, "5")
def boton7(label):
    agregar_caracter(label, "6")
def boton8(label):
    agregar_caracter(label, "*")
def boton9(label):
    agregar_caracter(label, "1")
def boton10(label):
    agregar_caracter(label, "2")
def boton11(label):
    agregar_caracter(label, "3")
def boton12(label):
    agregar_caracter(label, "+")
def boton13(label):
    agregar_caracter(label, "0")
def boton14(label):
    limpiar_pantalla(label) 
def boton15(label):
    calcular_resultado(label) 
def boton16(label):
    agregar_caracter(label, "-")
