import tkinter as tk

from calculadora_backend import boton1, boton2, boton3, boton4, boton5, boton6, boton7, boton8, boton9, boton10, boton11, boton12, boton13, boton14, boton15, boton16

root = tk.Tk()
root.title("Calculadora Básica")
root.configure(background="cyan")


root.rowconfigure(0, weight=2) 
root.rowconfigure(1, weight=1) 

root.rowconfigure(2, weight=1)
root.rowconfigure(3, weight=1)
root.rowconfigure(4, weight=1)
root.rowconfigure(5, weight=1)

root.columnconfigure(0, weight=1)
root.columnconfigure(1, weight=1)
root.columnconfigure(2, weight=1)
root.columnconfigure(3, weight=1)


label = tk.Label(root, text="", anchor="e", font=('Arial', 24), bg="white", fg="black")
label.grid(row=0, column=0, columnspan=4, sticky="nsew", padx=5, pady=5)



btn1 = tk.Button(root, text="7", command=lambda: boton1(label) )
btn1.grid(row=2, column=0,  sticky="nsew")

btn2 = tk.Button(root, text="8", command=lambda: boton2(label) )
btn2.grid(row=2, column=1, sticky="nsew")

btn3 = tk.Button(root, text="9", command=lambda: boton3(label) )
btn3.grid(row=2, column=2, sticky="nsew") 

btn4 = tk.Button(root, text="/", command=lambda: boton4(label))
btn4.grid(row=2, column=3, sticky="nsew") 

btn5 = tk.Button(root, text="4", command=lambda: boton5(label) )
btn5.grid(row=3, column=0, sticky="nsew")

btn6 = tk.Button(root, text="5", command=lambda: boton6(label) )
btn6.grid(row=3, column=1, sticky="nsew")

btn7 = tk.Button(root, text="6", command=lambda: boton7(label))
btn7.grid(row=3, column=2, sticky="nsew")

btn8 = tk.Button(root, text="*", command=lambda: boton8(label))
btn8.grid(row=3, column=3, sticky="nsew")


btn9 = tk.Button(root, text="1", command=lambda: boton9(label) )
btn9.grid(row=4, column=0, sticky="nsew")

btn10 = tk.Button(root, text="2", command=lambda: boton10(label))
btn10.grid(row=4, column=1, sticky="nsew")

btn11 = tk.Button(root, text="3", command=lambda: boton11(label))
btn11.grid(row=4, column=2, sticky="nsew")

btn12 = tk.Button(root, text="+", command=lambda: boton12(label))
btn12.grid(row=4, column=3, sticky="nsew")


btn13 = tk.Button(root, text="0", command=lambda: boton13(label))
btn13.grid(row=5, column=0, sticky="nsew")

btn14 = tk.Button(root, text="AC", command=lambda: boton14(label)) 
btn14.grid(row=5, column=1, sticky="nsew")

btn15 = tk.Button(root, text="=", command=lambda: boton15(label)) 
btn15.grid(row=5, column=2, sticky="nsew")

btn16 = tk.Button(root, text="-", command=lambda: boton16(label))
btn16.grid(row=5, column=3, sticky="nsew")


root.mainloop()
